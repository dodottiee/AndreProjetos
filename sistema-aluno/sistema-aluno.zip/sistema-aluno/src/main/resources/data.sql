INSERT INTO aluno (nome, email, curso) VALUES 
('João da Silva', 'joao.silva@email.com', 'Ciência da Computação'),
('Maria Oliveira', 'maria.oliveira@email.com', 'Engenharia de Produção'),
('Pedro Santos', 'pedro.santos@email.com', 'Administração'),
('Ana Souza', 'ana.souza@email.com', 'Ciência da Computação'),
('Carlos Pereira', 'carlos.pereira@email.com', 'Engenharia Elétrica');